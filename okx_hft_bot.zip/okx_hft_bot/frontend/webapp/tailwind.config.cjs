module.exports = {
  content: ['./index.html', './src/**/*.{vue,js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        bg: '#0a0f14',
        panel: '#0e1620',
        accent: '#00f5d4',
        accent2: '#00c2ff',
        danger: '#ff6b6b'
      },
      boxShadow: {
        neon: '0 0 15px rgba(0, 245, 212, 0.4), 0 0 30px rgba(0, 194, 255, 0.2)',
        card: '0 10px 30px rgba(0,0,0,0.45)'
      },
      keyframes: {
        glow: { '0%,100%': { boxShadow: '0 0 6px rgba(0,245,212,.5)' }, '50%': { boxShadow: '0 0 20px rgba(0,245,212,.9)' } },
        flow: { '0%': { backgroundPosition: '0% 50%'}, '100%': { backgroundPosition: '200% 50%'} },
        shimmer: { '0%': { transform: 'translateX(-100%)'}, '100%': { transform: 'translateX(100%)'} }
      },
      animation: {
        glow: 'glow 2.8s ease-in-out infinite',
        flow: 'flow 6s linear infinite',
        shimmer: 'shimmer 1.2s linear infinite'
      }
    }
  },
  plugins: []
}
