import { ref, onMounted, onUnmounted } from 'vue'

export default function useWebsocket(url = "ws://localhost:8000/ws") {
  const messages = ref([])
  let socket = null

  const sendMessage = (msg) => {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify(msg))
    }
  }

  onMounted(() => {
    socket = new WebSocket(url)

    socket.onopen = () => {
      console.log("✅ WebSocket 连接成功:", url)
    }

    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data)
        messages.value.push(data)
      } catch (e) {
        console.error("❌ WebSocket 消息解析失败:", e)
      }
    }

    socket.onclose = () => {
      console.log("❌ WebSocket 已关闭")
    }
  })

  onUnmounted(() => {
    if (socket) socket.close()
  })

  return { messages, sendMessage }
}
