import { createRouter, createWebHistory } from 'vue-router'
import DashboardPage from '../views/DashboardPage.vue'
import BacktestPage from '../components/BacktestPage.vue'

const routes = [
  { path: '/', component: DashboardPage },
  { path: '/backtest', component: BacktestPage }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
