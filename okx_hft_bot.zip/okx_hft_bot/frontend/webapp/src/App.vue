<template>
  <div class="app-container">
    <!-- 顶部导航 -->
    <nav class="navbar">
      <h1 class="logo">⚡ OKX HFT Dashboard</h1>
      <div class="nav-links">
        <router-link to="/" class="nav-item">Dashboard</router-link>
        <router-link to="/backtest" class="nav-item">Backtest</router-link>
      </div>
    </nav>

    <!-- 主体 -->
    <main class="main-content">
      <router-view />
    </main>

    <!-- 页脚 -->
    <footer class="footer">
      <p>🚀 OKX HFT Bot • 强烈建议先用 SIM 模式测试</p>
    </footer>
  </div>
</template>

<script>
export default { name: "App" }
</script>

<style>
/* 暗黑全局背景 */
.app-container {
  min-height: 100vh;
  background: radial-gradient(circle at top left, #0f172a, #000);
  color: #e5e7eb;
  font-family: 'Roboto', 'Segoe UI', sans-serif;
  display: flex;
  flex-direction: column;
}

/* 顶部导航 */
.navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 2rem;
  background: rgba(17, 24, 39, 0.9);
  border-bottom: 1px solid #1f2937;
  backdrop-filter: blur(10px);
}

.logo {
  font-size: 1.25rem;
  font-weight: bold;
  color: #38bdf8;
  text-shadow: 0 0 8px #38bdf8;
}

.nav-links {
  display: flex;
  gap: 1rem;
}
.nav-item {
  color: #9ca3af;
  text-decoration: none;
  transition: all 0.2s;
}
.nav-item:hover {
  color: #38bdf8;
  text-shadow: 0 0 8px #38bdf8;
}

/* 主体内容 */
.main-content {
  flex: 1;
  padding: 2rem;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

/* 页脚 */
.footer {
  text-align: center;
  padding: 0.75rem;
  font-size: 0.8rem;
  color: #6b7280;
  background: #111827;
}

/* 卡片样式 */
.card {
  background: rgba(31, 41, 55, 0.85);
  border: 1px solid #374151;
  border-radius: 0.75rem;
  padding: 1rem;
  box-shadow: 0 0 12px rgba(56, 189, 248, 0.15);
  transition: transform 0.2s, box-shadow 0.2s;
}
.card:hover {
  transform: translateY(-4px);
  box-shadow: 0 0 16px rgba(56, 189, 248, 0.3);
}

/* 标题 */
.section-title {
  font-size: 1.1rem;
  margin-bottom: 0.5rem;
  color: #38bdf8;
  font-weight: bold;
}
</style>