<template>
  <div class="grid grid-cols-3 gap-6">
    <!-- 行情监控 -->
    <div class="card col-span-2">
      <h2 class="section-title">📈 实时行情监控</h2>
      <instrument-chart />
    </div>

    <!-- WebSocket 消息 -->
    <div class="card">
      <h2 class="section-title">🛰 WebSocket 消息</h2>
      <p v-if="!messages.length">暂无数据，等待推送...</p>
      <ul>
        <li v-for="(msg, idx) in messages" :key="idx">{{ msg }}</li>
      </ul>
    </div>

    <!-- 系统日志 -->
    <div class="card col-span-3">
      <h2 class="section-title">🗄 系统日志</h2>
      <div class="log-box">
        <p v-for="(log, idx) in logs" :key="idx">{{ log }}</p>
      </div>
    </div>
  </div>
</template>

<script>
import InstrumentChart from "../components/InstrumentChart.vue"

export default {
  name: "DashboardPage",
  components: { InstrumentChart },
  data() {
    return {
      messages: [],
      logs: ["系统启动成功", "等待行情推送..."]
    }
  }
}
</script>

<style>
.log-box {
  max-height: 200px;
  overflow-y: auto;
  font-size: 0.9rem;
  background: #0f172a;
  padding: 0.5rem;
  border-radius: 0.5rem;
}
</style>