<template>
  <div ref="chartRef" class="chart"></div>
</template>

<script>
import * as echarts from "echarts"

export default {
  name: "InstrumentChart",
  data() {
    return {
      chart: null,
      data: [],
      timer: null
    }
  },
  mounted() {
    this.initChart()
    this.startDataFeed()
    window.addEventListener("resize", this.resizeChart)
  },
  beforeUnmount() {
    if (this.timer) clearInterval(this.timer)
    window.removeEventListener("resize", this.resizeChart)
    if (this.chart) this.chart.dispose()
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$refs.chartRef)

      const option = {
        backgroundColor: "transparent",
        tooltip: {
          trigger: "axis",
          backgroundColor: "rgba(30,41,59,0.9)",
          borderColor: "#38bdf8",
          borderWidth: 1,
          textStyle: { color: "#e5e7eb" }
        },
        grid: {
          left: "3%",
          right: "3%",
          bottom: "3%",
          top: "8%",
          containLabel: true
        },
        xAxis: {
          type: "category",
          boundaryGap: false,
          axisLine: { lineStyle: { color: "#475569" } },
          axisLabel: { color: "#9ca3af" },
          data: []
        },
        yAxis: {
          type: "value",
          axisLine: { lineStyle: { color: "#475569" } },
          splitLine: { lineStyle: { color: "#1e293b" } },
          axisLabel: { color: "#9ca3af" }
        },
        series: [
          {
            name: "价格走势",
            type: "line",
            smooth: true,
            symbol: "circle",
            showSymbol: false,
            lineStyle: { width: 2, color: "#38bdf8" },
            itemStyle: { color: "#38bdf8" },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: "rgba(56, 189, 248, 0.4)" },
                { offset: 1, color: "rgba(56, 189, 248, 0)" }
              ])
            },
            data: []
          }
        ]
      }

      this.chart.setOption(option)
    },
    updateChart() {
      const option = this.chart.getOption()
      option.xAxis[0].data = this.data.map((_, idx) => idx)
      option.series[0].data = this.data
      this.chart.setOption(option)
    },
    startDataFeed() {
      // 模拟实时推送：每 1 秒生成一个随机价格
      this.timer = setInterval(() => {
        const newPrice =
          (this.data.length ? this.data[this.data.length - 1] : 1000) +
          (Math.random() - 0.5) * 10
        this.data.push(newPrice.toFixed(2))
        if (this.data.length > 50) this.data.shift()
        this.updateChart()
      }, 1000)
    },
    resizeChart() {
      if (this.chart) this.chart.resize()
    }
  }
}
</script>

<style>
.chart {
  width: 100%;
  height: 400px;
  background: rgba(15, 23, 42, 0.6);
  border-radius: 12px;
  box-shadow: 0 0 20px rgba(56, 189, 248, 0.15);
}
</style>