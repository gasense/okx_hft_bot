<template>
  <div class="p-4 bg-gray-800 text-white rounded-md h-full flex flex-col">
    <h2 class="text-lg font-bold mb-2">📊 实时行情监控</h2>

    <!-- 仪表区 -->
    <div class="flex gap-4 mb-4">
      <instrument-list class="flex-1 card" />
      <instrument-chart class="flex-1 card" />
    </div>

    <!-- WebSocket 数据区 -->
    <div class="flex-1 overflow-y-auto bg-gray-900 rounded p-3 text-sm">
      <div class="font-bold mb-2">WebSocket 消息：</div>
      <div v-if="messages.length === 0" class="text-gray-400">
        暂无数据，等待推送...
      </div>
      <ul>
        <li v-for="(msg, idx) in messages" :key="idx" class="mb-1">
          {{ msg }}
        </li>
      </ul>
    </div>

    <!-- 输入消息测试 -->
    <div class="mt-3 flex gap-2">
      <input
        v-model="inputMsg"
        @keyup.enter="send"
        placeholder="输入测试消息后回车发送"
        class="flex-1 px-2 py-1 rounded text-black"
      />
      <button
        @click="send"
        class="px-4 py-1 bg-blue-600 hover:bg-blue-500 rounded"
      >
        发送
      </button>
    </div>
  </div>
</template>

<script>
import InstrumentList from './InstrumentList.vue'
import InstrumentChart from './InstrumentChart.vue'
import useWebsocket from '../composables/useWebsocket'
import { ref } from 'vue'

export default {
  name: 'Dashboard',
  components: { InstrumentList, InstrumentChart },
  setup () {
    // 使用 WebSocket Hook
    const { messages, sendMessage } = useWebsocket("ws://192.168.9.100:8000/ws")

    // 输入框
    const inputMsg = ref("")

    const send = () => {
      if (inputMsg.value.trim()) {
        sendMessage({ text: inputMsg.value })
        inputMsg.value = ""
      }
    }

    return { messages, inputMsg, send }
  }
}
</script>

<style scoped>
.card {
  background: #1f2937;
  border: 1px solid #374151;
  border-radius: 0.5rem;
  padding: 1rem;
}
</style>