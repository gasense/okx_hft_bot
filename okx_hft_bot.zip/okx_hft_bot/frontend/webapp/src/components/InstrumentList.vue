<template>
  <div class="p-2">
    <div class="flex items-center justify-between mb-2">
      <div class="font-semibold">交易对</div>
      <div class="text-xs text-[color:var(--muted)]">按涨速排序</div>
    </div>
    <div v-for="inst in instsSorted" :key="inst.instId" @click="$emit('select', inst.instId)"
         class="flex items-center justify-between p-2 rounded-md cursor-pointer hover:bg-white/5 transition-colors border border-white/5 mb-1">
      <div>
        <div class="font-semibold">{{ inst.instId }}</div>
        <div class="text-xs text-[color:var(--muted)]">Vol: {{ Number(inst.vol).toFixed(2) }}</div>
      </div>
      <div class="text-right">
        <div :class="inst.vel>0 ? 'text-accent' : 'text-danger'">{{ (inst.vel*1000).toFixed(6) }}</div>
        <div class="text-xs text-[color:var(--muted)]">Last: {{ Number(inst.last).toFixed(2) }}</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props:{ instruments:{type:Array, default:()=>[]} },
  computed:{
    instsSorted(){ return [...this.instruments].sort((a,b)=> b.vel - a.vel) }
  }
}
</script>