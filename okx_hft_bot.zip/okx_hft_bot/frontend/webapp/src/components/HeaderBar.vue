<template>
  <div class="card neon-border p-3 flex items-center justify-between">
    <div class="flex items-center gap-3">
      <div class="text-lg font-bold tracking-wide">OKX HFT <span class="text-accent">Dashboard</span></div>
      <div class="badge">Mode: {{ mode }}</div>
    </div>
    <div class="flex gap-2">
      <button class="btn btn-accent" @click="$emit('open-settings')">Settings</button>
      <button class="btn" @click="$emit('refresh')">Refresh</button>
    </div>
  </div>
</template>

<script>
export default { props:{ mode:{type:String,default:'SIM'} } }
</script>