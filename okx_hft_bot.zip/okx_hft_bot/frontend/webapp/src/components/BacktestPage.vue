<template>
  <div class="p-6 text-white">
    <h2 class="text-xl mb-4">回测页面</h2>
    <p>这里会显示回测结果。</p>
  </div>
</template>

<script>
export default {
  name: "BacktestPage"
}
</script>
