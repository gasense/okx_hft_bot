<template>
  <div class="p-4 bg-gray-800 text-white">
    <h2 class="text-lg">设置面板</h2>
    <button @click="$emit('close')" class="mt-2 px-4 py-2 bg-blue-600 rounded">关闭</button>
  </div>
</template>

<script>
export default {
  name: "SettingsPanel"
}
</script>
