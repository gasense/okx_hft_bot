#!/usr/bin/env bash
set -e

# 1) 安装 Docker & Compose
if ! command -v docker >/dev/null 2>&1; then
  sudo apt update && sudo apt install -y ca-certificates curl gnupg lsb-release
  sudo mkdir -p /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
  sudo apt update && sudo apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
  sudo systemctl enable --now docker
fi

# 2) 环境文件
if [ ! -f "./backend/.env" ]; then
  cat > ./backend/.env <<EOF
OKX_API_KEY=           # TODO: 必填
OKX_SECRET_KEY=        # TODO: 必填
OKX_PASSPHRASE=        # TODO: 必填
OKX_BASE_URL=https://www.okx.com
OKX_WS_URL=wss://ws.okx.com:8443/ws/v5/public
MODE=SIM               # 初次务必 SIM
DATA_DB=sqlite+aiosqlite:///./data.sqlite
VELOCITY_WINDOW_MS=200
VELOCITY_THRESHOLD=0.0015
MIN_VOLUME=0.01
MAX_ORDERS_PER_2S=800
ADMIN_EMAIL=
EOF
  echo "[+] 已创建 ./backend/.env，请填写 OKX 凭据（先 Demo 再实盘）"
fi

# 3) 构建并启动
sudo docker compose build
sudo docker compose up -d

echo "[+] 启动完成。前端: http://<你的服务器IP>  后端: http://<你的服务器IP>:8000/api/ping"