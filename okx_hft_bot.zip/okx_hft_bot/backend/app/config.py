import os
from pydantic import BaseSettings

class Settings(BaseSettings):
    OKX_API_KEY: str = ""  # TODO: 填写 OKX API Key
    OKX_SECRET_KEY: str = ""  # TODO: 填写 OKX Secret
    OKX_PASSPHRASE: str = ""  # TODO: 填写 OKX Passphrase
    OKX_BASE_URL: str = "https://www.okx.com"  # 或 my.okx.com (视地区)
    OKX_WS_URL: str = "wss://ws.okx.com:8443/ws/v5/public"

    MODE: str = "SIM"  # SIM 或 LIVE. 默认 SIM
    DATA_DB: str = "sqlite+aiosqlite:///./data.sqlite"

    # 策略参数（示例）
    VELOCITY_WINDOW_MS: int = 200  # 计算速度的窗口（毫秒）
    VELOCITY_THRESHOLD: float = 0.0015  # 价格速度阈值（示例，单位: price per ms）
    MIN_VOLUME: float = 0.01  # 最小成交量过滤

    # 速率限制保护
    MAX_ORDERS_PER_2S: int = 800  # 注意：请参照 OKX 实际限制并调整
    # Logging / admin
    ADMIN_EMAIL: str = ""  # TODO

    class Config:
        env_file = ".env"

settings = Settings()