import asyncio
import json
import time
from .okx_client import OKXMarketWS, OKXRest
from .strategy.velocity_strategy import VelocityStrategy
from .config import settings

class MarketBus:
    def __init__(self):
        self.ws = OKXMarketWS()
        self.rest = OKXRest()
        self.strategies = {}
        self._broadcast = None
        self._auto_checker = lambda: False

    def set_broadcaster(self, func):
        self._broadcast = func

    def set_auto_checker(self, func):
        self._auto_checker = func

    async def start(self, inst_list):
        await self.ws.connect()
        self.ws.on_message = self._on_msg
        for inst in inst_list:
            await self.ws.subscribe("tickers", inst)
            self.strategies[inst] = VelocityStrategy(inst, self._send_order)
        asyncio.create_task(self.ws.run_forever())

    async def _on_msg(self, data):
        if data.get("arg", {}).get("channel") == "tickers":
            for d in data.get("data", []):
                inst = d.get("instId")
                price = float(d.get("last"))
                ts = int(time.time()*1000)
                vol = float(d.get("vol", 0))
                vel = 0.0
                # 策略计算
                strat = self.strategies.get(inst)
                if strat:
                    # 让策略内部计算速度，并可能下单
                    strat.on_tick(ts, price, vol)
                    # 透传最近速度（简单示例：用当前价格与缓冲区首价近似）
                    if len(strat.buf) >= 2:
                        p0_ts, p0 = strat.buf[0]
                        dt = ts - p0_ts
                        if dt > 0: vel = (price - p0) / dt
                # 推送给前端
                if self._broadcast:
                    await self._broadcast({"type":"ticker","data":{
                        "instId": inst, "last": price, "vol": vol, "vel": vel, "ts": ts
                    }})

    async def _send_order(self, instId, side, price, size, ord_type="market"):
        if settings.MODE == "SIM":
            if self._broadcast:
                await self._broadcast({"type":"order","data":{
                    "instId": instId, "side": side, "px": price, "sz": size, "sim": True, "ts": int(time.time()*1000)
                }})
            return {"code": "0", "msg": "simulated"}
        # LIVE
        res = await self.rest.place_order(instId, side, price, size, ord_type=ord_type)
        if self._broadcast:
            await self._broadcast({"type":"order","data":{
                "instId": instId, "side": side, "px": price, "sz": size, "resp": res, "ts": int(time.time()*1000)
            }})
        return res
