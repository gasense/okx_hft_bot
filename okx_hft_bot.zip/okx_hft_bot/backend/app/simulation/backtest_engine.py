import pandas as pd
from ..strategy.velocity_strategy import VelocityStrategy

class BacktestEngine:
    def __init__(self, data_path, strategy_params=None):
        self.df = pd.read_csv(data_path)
        self.df = self.df.sort_values("ts")
        self.strategy = VelocityStrategy("BTC-USDT", self.fake_order, strategy_params)
        self.orders = []
        self.pnl = 0.0

    def fake_order(self, instId, side, px, sz, ord_type="limit"):
        self.orders.append({"instId":instId, "side":side, "px":px, "sz":sz})

    def run(self):
        for _, row in self.df.iterrows():
            self.strategy.on_tick(int(row["ts"]), float(row["price"]), float(row["volume"]))
        return self._analyze()

    def _analyze(self):
        balance = 0.0
        pos = 0.0
        entry_price = None
        curve = []
        for _, row in self.df.iterrows():
            price = float(row["price"])
            # 简化：按 strategy.position 估算盈亏
            if self.strategy.position != 0 and entry_price:
                pnl = (price - entry_price) * self.strategy.position
            else:
                pnl = 0
            curve.append({"ts": row["ts"], "price": price, "pnl": pnl})
        return {"orders": self.orders, "curve": curve}