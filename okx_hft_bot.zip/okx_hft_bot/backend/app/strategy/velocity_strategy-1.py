import time
import collections
import numpy as np
from ..config import settings

class VelocityStrategy:
    def __init__(self, instrument_id: str, send_order_callback):
        self.inst = instrument_id
        self.buf = collections.deque()  # store (ts_ms, price)
        self.window_ms = settings.VELOCITY_WINDOW_MS
        self.threshold = settings.VELOCITY_THRESHOLD
        self.send_order = send_order_callback
        self.last_action_ts = 0

    def on_tick(self, ts_ms: int, price: float, volume: float):
        # accumulate
        self.buf.append((ts_ms, price))
        # pop old
        while self.buf and (ts_ms - self.buf[0][0]) > self.window_ms:
            self.buf.popleft()
        # need minimum 2 points
        if len(self.buf) < 2:
            return
        # compute velocity: (p_now - p_old) / dt
        p0_ts, p0 = self.buf[0]
        dt = (ts_ms - p0_ts)
        if dt <= 0:
            return
        vel = (price - p0) / dt  # price per ms
        # simple trigger
        if vel > self.threshold and (time.time()*1000 - self.last_action_ts) > 500:  # anti-spam 500ms
            # send buy order (分批示例)
            qty = max(settings.MIN_VOLUME, 0.001)  # TODO: 根据账户资金计算
            # 使用回调下单：send_order(inst, side, price, size, ord_type)
            self.send_order(self.inst, "buy", price, qty, ord_type="market")
            self.last_action_ts = time.time()*1000
        # 如果速度回落到接近0或者为负可触发卖出（示例）
        if vel < self.threshold * 0.2:
            # 卖出（示例：全部平仓逻辑需基于持仓）
            self.send_order(self.inst, "sell", price, qty, ord_type="market")
            self.last_action_ts = time.time()*1000