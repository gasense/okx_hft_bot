import time
import math
from collections import deque

class VelocityStrategy:
    def __init__(self, instId, order_func, params=None):
        self.instId = instId
        self.order_func = order_func
        self.params = params or {
            "velocity_threshold": 0.0015,
            "window_ms": 200,
            "max_position": 0.01,        # 最大仓位（BTC单位）
            "split_orders": 3,           # 分批下单数量
            "slippage_bps": 5,           # 滑点估计（基点）
            "take_profit": 0.003,        # 止盈（0.3%）
            "stop_loss": -0.002          # 止损（-0.2%）
        }
        self.buf = deque(maxlen=50)
        self.position = 0.0
        self.entry_price = None

    def on_tick(self, ts, price, volume):
        self.buf.append((ts, price))
        if len(self.buf) < 2:
            return None

        t0, p0 = self.buf[0]
        dt = ts - t0
        if dt <= 0:
            return None

        vel = (price - p0) / dt
        signal = None

        # 做多信号
        if vel > self.params["velocity_threshold"] and self.position < self.params["max_position"]:
            signal = "buy"
            self._execute_order(price, "buy")

        # 做空信号
        elif vel < -self.params["velocity_threshold"] and self.position > -self.params["max_position"]:
            signal = "sell"
            self._execute_order(price, "sell")

        # 止盈止损
        if self.entry_price:
            pnl_ratio = (price - self.entry_price) / self.entry_price * (1 if self.position > 0 else -1)
            if pnl_ratio >= self.params["take_profit"] or pnl_ratio <= self.params["stop_loss"]:
                side = "sell" if self.position > 0 else "buy"
                signal = f"exit_{side}"
                self._execute_order(price, side, exit_all=True)

        return {"instId": self.instId, "signal": signal, "price": price, "vel": vel}

    def _execute_order(self, ref_price, side, exit_all=False):
        size = abs(self.params["max_position"]) / self.params["split_orders"]
        if exit_all:
            size = abs(self.position)

        # 滑点估计（bps）
        slippage = ref_price * self.params["slippage_bps"] / 10000
        px = ref_price + slippage if side == "buy" else ref_price - slippage

        for _ in range(self.params["split_orders"] if not exit_all else 1):
            self.order_func(self.instId, side, px, size, ord_type="limit")

        # 更新仓位
        if side == "buy":
            self.position += size
            if not self.entry_price:
                self.entry_price = ref_price
        else:
            self.position -= size
            if self.position == 0:
                self.entry_price = None