import time
import hmac, hashlib, base64
import json
import asyncio
import httpx
import websockets
from .config import settings

# REST signing for OKX v5
def sign_okx(method: str, request_path: str, body: str = ""):
    ts = str(time.time())
    prehash = ts + method.upper() + request_path + (body or "")
    mac = hmac.new(settings.OKX_SECRET_KEY.encode(), prehash.encode(), hashlib.sha256)
    sign = base64.b64encode(mac.digest()).decode()
    return ts, sign

class OKXRest:
    def __init__(self):
        self.base = settings.OKX_BASE_URL
        self.client = httpx.AsyncClient(base_url=self.base, timeout=10.0)

    async def place_order(self, instId, side, px, sz, ord_type="market"):
        """
        下单示例（spot/margin等需根据币种类型调整）
        ord_type: market/limit
        """
        path = "/api/v5/trade/order"
        body = {
            "instId": instId,
            "tdMode": "cash",  # TODO: 根据账户类型调整 margin/isolated
            "side": side,
            "ordType": ord_type,
            "sz": str(sz)
        }
        if ord_type == "limit":
            body["px"] = str(px)
        body_json = json.dumps(body)
        ts, sign = sign_okx("POST", path, body_json)
        headers = {
            "OK-ACCESS-KEY": settings.OKX_API_KEY,
            "OK-ACCESS-SIGN": sign,
            "OK-ACCESS-TIMESTAMP": ts,
            "OK-ACCESS-PASSPHRASE": settings.OKX_PASSPHRASE,
            "Content-Type": "application/json"
        }
        resp = await self.client.post(path, data=body_json, headers=headers)
        return resp.json()

class OKXMarketWS:
    def __init__(self):
        self.url = settings.OKX_WS_URL
        self.ws = None
        self.subscribed = set()
        self.on_message = None  # 回调: async def on_message(msg): ...

    async def connect(self):
        self.ws = await websockets.connect(self.url)
        # OKX v5 public channels: subscribe with {"op":"subscribe", "args":[{"channel":"tickers","instId":"BTC-USDT"}]}
        # 登录非必须，public channel 不需要签名
        return self.ws

    async def subscribe(self, channel: str, instId: str):
        if not self.ws:
            await self.connect()
        req = {"op":"subscribe", "args":[{"channel":channel, "instId":instId}]}
        await self.ws.send(json.dumps(req))
        self.subscribed.add((channel, instId))

    async def run_forever(self):
        async for msg in self.ws:
            try:
                data = json.loads(msg)
            except Exception:
                continue
            if self.on_message:
                await self.on_message(data)