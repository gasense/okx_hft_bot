import asyncio
import json
from typing import Set
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from .market_bus import MarketBus
from .config import settings

app = FastAPI(title="OKX HFT Bot API")

# 允许前端跨域（开发阶段可放宽，生产请精确到域名）
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # TODO: 生产环境改为你的前端域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

mb = MarketBus()
clients: Set[WebSocket] = set()
auto_enabled = False

async def broadcast(event: dict):
    data = json.dumps(event, ensure_ascii=False)
    living = set()
    for ws in clients:
        try:
            await ws.send_text(data)
            living.add(ws)
        except Exception:
            # 连接已断开
            pass
    clients.clear()
    clients.update(living)

# 将广播函数注入到 market bus
mb.set_broadcaster(broadcast)

@app.on_event("startup")
async def startup_event():
    instruments = ["BTC-USDT", "ETH-USDT"]  # TODO: 可改为全量，注意速率与负载
    asyncio.create_task(mb.start(instruments))

@app.get("/api/ping")
async def ping():
    return {"status": "ok", "mode": settings.MODE, "auto": auto_enabled}

@app.websocket("/ws/market")
async def ws_market(ws: WebSocket):
    await ws.accept()
    clients.add(ws)
    # 首次连接发送握手信息
    await ws.send_json({"type": "hello", "data": {"mode": settings.MODE}})
    try:
        while True:
            # 等待前端控制消息（start_auto/stop_auto/manual_order）
            msg = await ws.receive_text()
            try:
                data = json.loads(msg)
            except Exception:
                continue
            action = data.get("action")
            if action == "start_auto":
                global auto_enabled
                auto_enabled = True
                await ws.send_json({"type":"info","data":{"message":"Auto strategy enabled"}})
            elif action == "stop_auto":
                auto_enabled = False
                await ws.send_json({"type":"info","data":{"message":"Auto strategy disabled"}})
            elif action == "manual_order":
                # 简化的手动下单（仅示例）
                inst = data.get("instId","BTC-USDT")
                side = data.get("side","buy")
                size = float(data.get("size", 0.001))
                price = 0.0
                res = await mb._send_order(inst, side, price, size, ord_type="market")
                await ws.send_json({"type":"order","data":{"instId":inst,"side":side,"sz":size,"resp":res}})
    except WebSocketDisconnect:
        if ws in clients:
            clients.remove(ws)
    except Exception:
        if ws in clients:
            clients.remove(ws)

# 由策略是否执行由 MarketBus 内部读取 auto_enabled（简单示例）
def is_auto_enabled():
    return auto_enabled

mb.set_auto_checker(is_auto_enabled)

from fastapi import UploadFile, File
from .simulation.backtest_engine import BacktestEngine
import tempfile

@app.post("/api/backtest")
async def run_backtest(file: UploadFile = File(None)):
    if file:
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".csv")
        tmp.write(await file.read())
        tmp.close()
        engine = BacktestEngine(tmp.name)
    else:
        # 用示例数据
        engine = BacktestEngine("app/simulation/sample_data.csv")
    result = engine.run()
    return result
