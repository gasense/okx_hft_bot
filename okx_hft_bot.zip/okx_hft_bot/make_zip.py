import shutil, os

def make_zip():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    target = os.path.join(base_dir, "okx_hft_bot.zip")
    if os.path.exists(target):
        os.remove(target)
    shutil.make_archive("okx_hft_bot", "zip", base_dir)
    print(f"[+] 打包完成: {target}")

if __name__ == "__main__":
    make_zip()